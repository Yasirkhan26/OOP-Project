/* PROGRAMMING FUNDAMENTAL'S PROJECT FOR FALL 2022 BS(CS)
 * Shape of each piece is represented by rows in the array.
 * TIP: Name the array what is already been coded to avoid any unwanted errors.
 */
 const int row=8 , column=4;
int BLOCKS[row][column]={{1,3,5,7},{4,5,6,7},{3,2,0,4},{3,2,4,6},{4,2,1,3},{3,2,5,7},{0,2,3,5},{0,0,0,0}};


